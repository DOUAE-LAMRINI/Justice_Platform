
from langdetect import detect
from argostranslate import translate

installed_languages = translate.load_installed_languages()
available_pairs = {
    (from_lang.code, to_lang.code): from_lang.get_translation(to_lang)
    for from_lang in installed_languages
    for to_lang in installed_languages
    if from_lang != to_lang
}

def detect_language(text):
    try:
        return detect(text)
    except Exception as e:
        print(f"Language detection error: {e}")
        return "unknown"

def translate_text(text, from_lang, to_lang):
    pair = available_pairs.get((from_lang, to_lang))
    if pair:
        try:
            return pair.translate(text)
        except Exception as e:
            print(f"Translation error ({from_lang}→{to_lang}): {e}")
            return text
    else:
        print(f"No available translation pair: {from_lang} → {to_lang}")
        return text
