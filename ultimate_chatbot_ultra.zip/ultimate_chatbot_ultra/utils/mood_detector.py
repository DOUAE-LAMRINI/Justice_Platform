
from transformers import pipeline
import torch

# Automatically use GPU if available
device = 0 if torch.cuda.is_available() else -1

emotion_pipeline = pipeline(
    "text-classification",
    model="finiteautomata/bertweet-base-emotion-analysis",
    return_all_scores=True,
    device=device
)

def detect_mood(text):
    try:
        scores = emotion_pipeline(text)[0]
        sorted_scores = sorted(scores, key=lambda x: x['score'], reverse=True)
        mood = sorted_scores[0]['label']
        confidence = round(sorted_scores[0]['score'], 4)
        return mood, confidence
    except Exception as e:
        print(f"Emotion detection error: {e}")
        return "unknown", 0.0
