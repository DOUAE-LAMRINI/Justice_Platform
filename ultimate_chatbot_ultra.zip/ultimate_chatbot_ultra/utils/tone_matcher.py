
def match_reply_tone(mood, base_reply, language="en"):
    mood = mood.lower()
    language = language.lower()

    tone_prefixes = {
        "en": {
            "joy": ["Wonderful! ", "That's fantastic! ", "So happy for you! "],
            "sadness": ["I'm here with you. ", "My heart goes out to you. ", "You're not alone. "],
            "anger": ["That sounds frustrating. ", "I'd be upset too. ", "Completely understandable. "],
            "fear": ["That must be frightening. ", "You're safe now. ", "That would scare me too. "],
            "surprise": ["Wow! ", "Amazing! ", "Incredible! "],
            "love": ["So touching! ", "Beautiful sentiment! ", "Warms my heart! "],
            "neutral": ["", "Got it. ", "I see. "]
        },
        "ar": {
            "joy": ["رائع! ", "هذا مذهل! ", "كم أنا سعيد لأجلك! "],
            "sadness": ["أنا هنا معك. ", "قلبي معك. ", "لست وحدك. "],
            "anger": ["هذا يبدو محبطًا. ", "سأكون غاضبًا أيضًا. ", "مفهوم تمامًا. "],
            "fear": ["لا بد أن هذا مخيف. ", "أنت آمن الآن. ", "هذا سيخيفني أيضًا. "],
            "surprise": ["وااو! ", "مدهش! ", "لا يصدق! "],
            "love": ["هذا مؤثر! ", "شعور جميل! ", "يدفئ قلبي! "],
            "neutral": ["", "فهمت. ", "حسنًا. "]
        },
        "fr": {
            "joy": ["Magnifique! ", "C'est fantastique! ", "Je suis si heureux pour toi! "],
            "sadness": ["Je suis là avec toi. ", "Tout mon soutien. ", "Tu n'es pas seul. "],
            "anger": ["Cela semble frustrant. ", "Je serais énervé aussi. ", "Tout à fait compréhensible. "],
            "fear": ["Cela doit être effrayant. ", "Tu es en sécurité maintenant. ", "Cela m'effraierait aussi. "],
            "surprise": ["Waouh! ", "Incroyable! ", "Impressionnant! "],
            "love": ["C'est touchant! ", "Un beau sentiment! ", "Ça réchauffe le cœur! "],
            "neutral": ["", "Compris. ", "Je vois. "]
        }
    }

    import random
    prefixes = tone_prefixes.get(language, tone_prefixes["en"]).get(mood, [""])
    prefix = random.choice(prefixes)

    return f"{prefix}{base_reply}"
