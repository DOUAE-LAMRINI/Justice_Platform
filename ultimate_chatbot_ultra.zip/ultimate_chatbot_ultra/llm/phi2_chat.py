
from transformers import AutoModelForCausalLM, AutoTokenizer, pipeline
import torch
from typing import Optional

def load_model():
    # Check if GPU is available and use it
    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Using device: {device}")
    
    model_id = "microsoft/phi-2"

    tokenizer = AutoTokenizer.from_pretrained(model_id, trust_remote_code=True)
    tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(
        model_id,
        torch_dtype=torch.float16 if device == "cuda" else torch.float32,
        low_cpu_mem_usage=True,
        trust_remote_code=True
    ).to(device)
    
    return model, tokenizer, device

_model, _tokenizer, _device = None, None, None

def generate_reply(prompt: str, max_tokens: int = 200) -> str:
    global _model, _tokenizer, _device

    if _model is None:
        _model, _tokenizer, _device = load_model()

    try:
        inputs = _tokenizer(prompt, return_tensors="pt", padding=True).to(_device)
        outputs = _model.generate(
            inputs.input_ids,
            max_new_tokens=max_tokens,
            do_sample=True,
            temperature=0.7,
            top_p=0.9
        )
        return _tokenizer.decode(outputs[0], skip_special_tokens=True)
    except Exception as e:
        return f"Error: {str(e)}"
