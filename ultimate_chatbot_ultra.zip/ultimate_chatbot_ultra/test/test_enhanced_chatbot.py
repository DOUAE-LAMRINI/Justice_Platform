
import sys
import os
sys.path.append("/content/drive/MyDrive/ultimate_chatbot_ultra")

import pytest
from chatbot.enhanced_chatbot import EnhancedChatbot

@pytest.fixture(scope="module")
def chatbot():
    return EnhancedChatbot(knowledge_threshold=0.5, debug=True)

@pytest.mark.parametrize("query, expected_lang", [
    ("Hello, how are you?", "en"),
    ("مرحبا، كيف حالك؟", "ar"),
    ("Bonjour, comment ça va ?", "fr"),
])
def test_language_detection(chatbot, query, expected_lang):
    result = chatbot.process_query(query)
    assert result["detected_language"] == expected_lang

@pytest.mark.parametrize("query", [
    "What is the capital of France?",
    "Tell me about Python programming.",
])
def test_basic_response_english(chatbot, query):
    result = chatbot.process_query(query)
    assert "response" in result
    assert isinstance(result["response"], str)
    assert result["timing"]["total_seconds"] < 10  # Should be fast
    assert result["source"] in ("phi2_model", "knowledge_base+phi2")

def test_multilingual_tone_and_translation(chatbot):
    query = "أنا حزين اليوم"
    result = chatbot.process_query(query)
    assert result["mood"] == "sad"
    assert result["detected_language"] == "ar"
    assert isinstance(result["response"], str)
    assert len(result["response"]) > 0

def test_kb_match_stats(chatbot):
    query = "What is AI?"
    result = chatbot.process_query(query)
    assert "knowledge_matches" in result
    assert isinstance(result["knowledge_matches"]["count"], int)
    assert 0 <= result["knowledge_matches"]["top_score"] <= 1

def test_fallback_on_invalid_input(chatbot):
    query = ""
    result = chatbot.process_query(query)
    assert isinstance(result["response"], str)
    assert len(result["response"]) > 0

def test_speed(chatbot):
    import time
    start = time.time()
    chatbot.process_query("Who discovered gravity?")
    duration = time.time() - start
    assert duration < 15
