
import torch
import json
import time
import logging
from typing import Dict, Optional, List, Tuple
from sentence_transformers import SentenceTransformer, util
from llm.phi2_chat import generate_reply
from utils.translator import detect_language, translate_text
from utils.mood_detector import detect_mood
from utils.tone_matcher import match_reply_tone

logging.basicConfig(level=logging.INFO)

class EnhancedChatbot:
    def __init__(self, knowledge_threshold: float = 0.7, debug: bool = False):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.knowledge_threshold = knowledge_threshold
        self.debug = debug
        self.embedder = SentenceTransformer('all-MiniLM-L6-v2', device=self.device)
        self._load_knowledge_base()
        self._warmup_models()

    def _log(self, msg: str):
        if self.debug:
            logging.info(msg)

    def _warmup_models(self):
        warmup_queries = ["hello", "مرحبا", "bonjour"]
        for query in warmup_queries:
            try:
                self.process_query(query)
            except Exception:
                pass

    def _load_knowledge_base(self):
        try:
            start_time = time.time()
            self.knowledge_embeddings = torch.load(
                "/content/drive/MyDrive/ultimate_chatbot_ultra/embeddings.pt",
                map_location=self.device,
                mmap=True if self.device == "cpu" else False
            )
            with open("/content/drive/MyDrive/ultimate_chatbot_ultra/texts.json", "r", encoding="utf-8") as f:
                self.knowledge_texts = json.load(f)

            if len(self.knowledge_texts) != self.knowledge_embeddings.shape[0]:
                raise ValueError("Texts and embeddings dimension mismatch!")

            logging.info(f" Knowledge base loaded in {time.time()-start_time:.2f}s | "
                         f"Texts: {len(self.knowledge_texts)} | "
                         f"Embeddings: {self.knowledge_embeddings.shape}")
        except Exception as e:
            logging.error(f" Knowledge base loading failed: {str(e)}")
            self.knowledge_embeddings = None
            self.knowledge_texts = []

    def _search_knowledge_base(self, query: str, top_k: int = 3) -> Tuple[Optional[List[str]], List[float]]:
        if not self.knowledge_embeddings or not self.knowledge_texts:
            return None, []

        with torch.no_grad():
            query_embedding = self.embedder.encode(
                query,
                convert_to_tensor=True,
                device=self.device,
                normalize_embeddings=True
            )
            cos_scores = util.cos_sim(query_embedding, self.knowledge_embeddings)[0]
            top_results = torch.topk(cos_scores, k=min(top_k, len(self.knowledge_texts)))

        results, scores = [], []
        for score, idx in zip(top_results.values, top_results.indices):
            if score.item() > self.knowledge_threshold:
                results.append(self.knowledge_texts[idx.item()])
                scores.append(score.item())

        return (results, scores) if results else (None, [])

    def process_query(self, user_input: str) -> Dict:
        start_time = time.time()
        metrics = {
            'translation_time': 0,
            'mood_detection_time': 0,
            'knowledge_search_time': 0,
            'generation_time': 0,
            'tone_matching_time': 0
        }

        input_lang = detect_language(user_input)
        english_input = user_input

        if input_lang != "en":
            trans_start = time.time()
            try:
                english_input = translate_text(user_input, input_lang, "en")
            except Exception as e:
                logging.warning(f" Translation error: {e}")
            metrics['translation_time'] = time.time() - trans_start

        mood_start = time.time()
        mood, confidence = detect_mood(user_input)
        metrics['mood_detection_time'] = time.time() - mood_start

        kb_start = time.time()
        kb_answers, similarity_scores = self._search_knowledge_base(english_input)
        metrics['knowledge_search_time'] = time.time() - kb_start

        gen_start = time.time()
        try:
            if kb_answers:
                context = "\n".join(
                    f"[KB Match {i+1}, Score: {s:.2f}]\n{a}"
                    for i, (a, s) in enumerate(zip(kb_answers, similarity_scores))
                )
                prompt = f"Context:\n{context}\n\nQuestion: {english_input}\nAnswer:"
                response = generate_reply(prompt)
                source = "knowledge_base+phi2"
            else:
                response = generate_reply(english_input)
                source = "phi2_model"
        except Exception as e:
            response = "Sorry, I'm having trouble generating a response right now."
            logging.error(f" Generation error: {e}")
            source = "error_fallback"
        metrics['generation_time'] = time.time() - gen_start

        if input_lang != "en":
            trans_start = time.time()
            try:
                response = translate_text(response, "en", input_lang)
            except Exception as e:
                logging.warning(f" Response translation error: {e}")
            metrics['translation_time'] += time.time() - trans_start

        tone_start = time.time()
        final_response = match_reply_tone(mood, response, input_lang)
        metrics['tone_matching_time'] = time.time() - tone_start

        total_time = time.time() - start_time

        return {
            "response": final_response,
            "detected_language": input_lang,
            "mood": mood,
            "confidence": float(confidence),
            "source": source,
            "timing": {
                "total_seconds": round(total_time, 2),
                **{k: round(v, 2) for k, v in metrics.items()}
            },
            "knowledge_matches": {
                "count": len(kb_answers) if kb_answers else 0,
                "top_score": round(max(similarity_scores), 2) if similarity_scores else 0
            }
        }

    def __call__(self, user_input: str) -> Dict:
        return self.process_query(user_input)
